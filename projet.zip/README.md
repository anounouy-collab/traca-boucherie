# Traça Boucherie Mmarket

Application Android de traçabilité pour la boucherie (réceptions, fabrications, lots, DLC, photos, tableau Excel du mois).
Elle fonctionne entièrement sur la tablette, sans compte et sans Internet. Les données restent dans la tablette.

L'APK est construit automatiquement par GitHub (onglet **Actions**) et publié dans **Releases**.
Lien de téléchargement direct de la dernière version :
`https://github.com/<votre-nom>/traca-boucherie/releases/latest/download/Traca-Boucherie-Mmarket.apk`
