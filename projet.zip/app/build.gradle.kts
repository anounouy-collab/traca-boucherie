plugins { id("com.android.application") }

android {
    namespace = "com.mmarket.traca"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mmarket.traca"
        minSdk = 24
        targetSdk = 34
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }
    signingConfigs {
        create("traca") {
            storeFile = file("traca.keystore")
            storePassword = "traca2026"
            keyAlias = "traca"
            keyPassword = "traca2026"
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("traca")
        }
        getByName("debug") { signingConfig = signingConfigs.getByName("traca") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.core:core:1.13.1")
}
